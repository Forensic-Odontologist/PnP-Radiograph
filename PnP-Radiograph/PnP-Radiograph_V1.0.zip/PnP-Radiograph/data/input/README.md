# Input — one DICOM radiograph

Put **exactly one** DICOM file here.

- Typical extensions: `.dcm`, `.dicom`, or **no extension** (some PACS exports).
- **JPG, PNG, TIFF, BMP, etc. are not supported** — convert or re-export as DICOM first.

Remove any extra files so this folder contains only the study instance you want to process.

(This file exists so the folder is tracked in Git; your DICOM stays **local** and is ignored — see root `.gitignore`.)
