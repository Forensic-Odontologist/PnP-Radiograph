# Data

Place your **single DICOM** radiograph in **`input/`** — see [`input/README.md`](input/README.md).

Raster formats are not supported in this workflow.
